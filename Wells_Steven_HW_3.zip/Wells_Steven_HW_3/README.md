# Steven Wells HW 3: Maze Creator

## Maze Rating

I implemented maze rating through a set of multiple functions. 

Since I am doing a type of maze where it is almost always relatively easy to find the solution, I chose to rate the mazes based on how fun they are. 

#### To do this, I used several metrics:

- % of cells in maze used for path generated. This percentage changes with different sizes of mazes, but for the largest type of maze that generated quickly enough (15x12), the maximum length percentage was 65% of all cells needed to be used in the path created by the maze generator (at the highest level of fun). In decreasing fun levels, the generator didn't need to use as many cells.
- Whether or not consecutive numbers are reachable before you can reach the 1 cell. I noticed how some mazes weren't very open and the first numbered cell you could even reach was number one, and I figure that this isn't very fun because it makes it easier to know exactly where to go. 
- Unexpected events:

    1. Whether or not the path passes by the end square no later than 2/3rds of the way down the path. If the path passes by the end square somewhat early on, I figured this would make for a more interesting maze than one where the path is more linear.

    2. Whether or not non-consecutively numbered squares are next to each other

#### Fun Score Categories

The levels of the 'fun score' for the maze range from 1 (least fun) to 4 (most fun) and they are categorized like this:

- 4 - Achieved when path length is the max length for the current grid size; you can reach other numbered cells than 1 before reaching the 1 cell; there is at least one 'unexpected event' in the maze
- 3 - Achieved when path length is at least 80% of max length for the current grid size; you can reach other numbered cells than 1 before reaching the 1 cell
- 2 - Achieved when path length is at least 65% of max length for the current grid size
- 1 - Achieved when path length is at least 50% of max length for the current grid size

## Maze Generation

I used several different separate methods to create my maze generation function. 

### Random Wall Maze Generation

The first method I coded for this feature was a function that just set random walls everywhere in the maze until a maze with a legitimate path was found. This one is not very interesting, and is somewhat unfinished as it never even sets any numbers - although I did utilize this method in my more advanced random path maze generation.

### Random Path Maze Generation

This is the type of generation that eventually ended up being my maze creation function.

#### Random Path Function 

The first step is that the function sets a start and an end cell in the maze, and walks down a randomly chosen path of cells until it reaches the end cell. I utilized my earlier 'legal_neighbors' function for the maze solver to make this process easier. I also added some code to account for the situations where the random path generator walls itself off into a corner - in these situations the path generator jumps the path back a number of steps (decided by the size of the grid of the maze) and continues from there, in the hope that it won't wall itself off again. I found that, when I ignored paths that were too small (paths that used less than 65% of all cells, in the case of a 15x12 maze), this random path generation function would be pretty quick to generate a sufficiently complex path. If I were to set the threshold above 65%, however, it would take exponentially longer amounts of time to generate any path at all.

#### Path Drawing Function

The next step in the process is to draw walls entirely enclosing the chosen path. This was accomplished by the Maze.draw_walls_around_path(path) function.

#### Number Placing Function

The following step was to place numbers along the chosen path. This function is generally pretty simple, it chooses a step value based on the overall size of the maze and steps along the path, sometimes a little more than the chosen step value and sometimes a little less, and places numbers down throughout the whole path. The function is called 'Maze.place_numbers_in_path(path)'.

#### Outer wall Removal Function

This is just a small helper function that removes any walls that were placed on the outer edges of the maze, just because those look a little bad stylistically in the gui I created.

#### Wall randomization function

The next major step in the process was to randomize the walls of the maze. This is the function that took inspiration from my original Random Wall Maze Generation function. All it does it step through every pair of cells that exists in the maze, and choose whether or not to flip the value of the wall between those cells based on which of the two cells are in the chosen path:

- If that pair of cells are consecutive cells in the chosen path, it will always keep the walls as off. If it didn't, the path would be broken!  
- In the cases that both cells are in the chosen path but they are not consecutive or only one of the cells is in the path, it has a 1/5 chance of flipping the wall values from on to off. This helps the path keep its general shape, but not only have one single possible path you can take through the maze.  
- In the case that neither cell is in the chosen path, it has a 1/2 chance of flipping the value of the wall, very similar to the functionality of the original Random Wall Generation function.  

#### Remove Cut-Off Sections of Maze

I noticed after implementing all of the previous functions that a very common occurance in mazes would be that there were a lot of sections that were just impossible to reach because they were walled off from the rest of the maze. I didn't like this, so I created the next function, called 'Maze.remove_cutoff_sections()'. This function just traverses through every cell in the maze that is possible to reach, and subtracts that from the set of every cell in the maze. If there are cells that are impossible to reach, it removes one random wall from one of those cells and recalculates which cells can be reached. It does this until no more unreachable cells remain.

#### Fun Score Checks

After all of this is done, then the generator function looks at the fun score that was passed into it and performs the checks associated with that fun score, as detailed in the previous section about 'Fun Score' metrics.

#### Final Length Check

To make sure that the new path after messing with the walls is still as long as was intended, the generator function calls my bfs solving algorithm and checks the new length of the path. If it is still close to long enough (minus 10% from original percantage used), then the maze is good to go! I didn't have it check that it was the same value as the originally used one, because doing that made it almost impossible to get a working maze.

## Mazes I Had My Creator Create and then Solved

I created two mazes of each of the different fun levels and solved them by hand. I feel like my metrics for amount of fun generally did make sense and correlated pretty well to how fun the mazes came out to be. 

The mazes of level 1 were definitely less complex and less interesting than the ones generated for fun level 4. Level 2 was a little better than level 1, and level 3 was a little better than level 2. However, mazes of level 3 and level 4 were both pretty interesting, they probably had the lowest difference in how fun they were for me compared to any of the other categories. 

I picked each of the mazes I did from each level because I thought they generally correlated well to what level they were generated from. The mazes at level 1 had small paths that were extremely easy to find quickly, and they generally got a little harder and more interesting with each level.

## Pictures of solved mazes

![](readme/1.png)


![](readme/2.png)


![](readme/3.png)


![](readme/4.png)